//////library//////////
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <windows.h>
#include <time.h>
#include <unistd.h>

////// variable /////////

#define ligne 20
#define colone 63

#define KEY_UP 72
#define KEY_DOWN 80
#define KEY_LEFT 75
#define KEY_RIGHT 77

const int speed = 60;
unsigned int st = 1;
unsigned int i, j;
unsigned int snakel, snakec;
unsigned int mangel, mangec;
unsigned int gameover = 0;
char nDir, nDir2;
int piece[ligne][colone];
int head = 4;
int Tail = 0;

void mange();

void initialisation() {
  head = 5;
  Tail = 0;
  snakel = ligne / 2;
  snakec = colone / 2;
  for (i = 0; i < ligne; i++) {
    for (j = 0; j < colone; j++) {
      piece[i][j] = 0;
    }
  }
  piece[snakel][snakec] = head;
  mange();
}

void mange() {
  srand(time(0));
  mangel = 1 + rand() % (ligne - 2);
  mangec = 1 + rand() % (colone - 2);

  if (piece[mangel][mangec] == 0) {
    piece[mangel][mangec] = -1;
  } else {
    mange();
  }
}

void game() {
  for (i = 0; i < ligne; i++) {
    for (j = 0; j < colone; j++) {
      if (i == 0 && j == 0) printf("\t \t \t %c", 201);
      else if (i == 0 && j == colone - 1) printf("%c", 187);
      else if (i == ligne - 1 && j == 0) printf("\t \t \t %c", 200);
      else if (i == ligne - 1 && j == colone - 1) printf("%c", 188);
      else if (i == 0 || i == ligne - 1) printf("%c", 205);
      else if (j == 0) printf("\t \t \t %c", 186);
      else if (j == colone - 1) printf("%c", 186);
      else {
        if (piece[i][j] == 0) {
        	printf(" ");
		}
        else if (piece[i][j] >= 1 && piece[i][j] != head){
        	printf("%c", 176);
		}
        else if (piece[i][j] == head){
        	printf("%c", 178);
		}
        else if (piece[i][j] == -1) {
        	printf("%c", 184);
		}
      }
    }
    printf("\n");
  }
}

void controle() {
  if (kbhit()) {
    nDir = getch();
    if (nDir == 0)
      nDir = getch();
  }
  if ( (nDir == KEY_UP && nDir2 != KEY_DOWN) || (nDir == KEY_DOWN && nDir2 != KEY_UP) || (nDir == KEY_RIGHT && nDir2 != KEY_LEFT) || (nDir == KEY_LEFT && nDir2 != KEY_RIGHT) ) {
    nDir2 = nDir;
  }
  if (st == 1) {
    nDir2 = KEY_UP;
    st = 0;
  }
  switch (nDir2) {
  case KEY_UP: {
    head++;
    snakel--;
    if (piece[snakel][snakec] != 0 && snakel != mangel) {
      gameover = 1;
    }
    piece[snakel][snakec] = head;
    break;
  }
  case KEY_DOWN: {
    head++;
    snakel++;
    if (piece[snakel][snakec] != 0 && snakel != mangel) {
      gameover = 1;
    }
    piece[snakel][snakec] = head;
    break;
  }
  case KEY_RIGHT: {
    head++;
    snakec++;
    if (piece[snakel][snakec] != 0 && snakec != mangec) {
      gameover = 1;
    }
    piece[snakel][snakec] = head;
    break;
  }
  case KEY_LEFT: {
    head++;
    snakec--;
    if (piece[snakel][snakec] != 0 && snakec != mangec) {
      gameover = 1;
    }
    piece[snakel][snakec] = head;
    break;
  }
	default:;
  }

  for (i = 0; i < ligne; i++) {
    for (j = 0; j < colone; j++) {
      if ((piece[i][j] == Tail)) {
        piece[i][j] = 0;
      }
    }
  }
  Tail++;

  if (snakel <= 0 || snakel >= ligne || snakec <= 0 || snakec >= colone) {
    gameover = 1;
  }

  if (snakel == mangel && snakec == mangec) {
    Tail -= 1;
    mange();
  }
}

void ResetScreenPosition() {
  HANDLE hOut;
  COORD Position;
  hOut = GetStdHandle(STD_OUTPUT_HANDLE);
  Position.X = 0;
  Position.Y = 0;
  SetConsoleCursorPosition(hOut, Position);
}


int main() {
  initialisation();
	while (gameover == 0) {
      Sleep(speed);
      controle();
      ResetScreenPosition();
      game();
    }
    return 0;
}
