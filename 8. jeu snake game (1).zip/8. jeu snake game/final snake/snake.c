//////library//////////
#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <windows.h>
#include "mmsystem.h"
#include <time.h>
#include <string.h>
#include <unistd.h>

////// variable /////////

#define ligne 20
#define colone 63

#define KEY_UP 72
#define KEY_DOWN 80
#define KEY_LEFT 75
#define KEY_RIGHT 77

FILE * f;
int com = 0, com1=0;
int pos = 0;
int pos_max;
int HS;
char bc;
int c, d;
int st = 1;
int get_int;
int i, j, k;
int snakel, snakec;
int mangel, mangec;
int speed;
int gameover = 0;
char nDir, nDir2, press;
int move = 0;
int cmp_user;
char lire[1];
int piece[ligne][colone];
int head = 4;
int Tail = 0;
int nb_total=0;

struct players {
  char user[5];
  int score;
  int nb_player;
}
player;

///////// files //////////

void data() {
  f = fopen(("%s", player.user), "a");
  if (f == NULL) {
    move = 10;
  } else {
    if (com == 1) {
      fputs("\n", f);
      fprintf(f, "nb_player : %d", player.nb_player);
      fputs("\n", f);
      fprintf(f, "user : %s", player.user);
      fputs("\n", f);
      com = 0;
    }
    fprintf(f, "score : %d", player.score);
    fputs("\n", f);
    fclose(f);
  }
}

void Highscore() {
  f = fopen("highscore.txt", "r");
  if (f == NULL) {
    move = 10;
  } else {
    fscanf(f, "%d", & get_int);
    fclose(f);
  }

  f = fopen("highscore.txt", "w");
  if (f == NULL) {
    move = 10;
  } else {
    HS = max(get_int, player.score);
    fprintf(f, "%d", HS);
    fclose(f);
  }
}

void nbPlayers() {
  f = fopen("nb_players.txt", "r");
  if (f == NULL) {
    move = 10;

  } else {
    fscanf(f, "%d", & get_int);
    fclose(f);
  }

  f = fopen("nb_players.txt", "w");
  if (f == NULL) {
    move = 10;
  } else {
    player.nb_player = get_int + 1;
    fprintf(f, "%d", player.nb_player);
    fclose(f);
  }
}

////// game //////

void mange();

void initialisation() {
  player.score = 0;
  head = 5;
  Tail = 0;
  snakel = ligne / 2;
  snakec = colone / 2;
  speed = 99;
  for (i = 0; i < ligne; i++) {
    for (j = 0; j < colone; j++) {
      piece[i][j] = 0;
    }
  }
  piece[snakel][snakec] = head;
  mange();
}

void mange() {
  srand(time(0));
  mangel = 1 + rand() % (ligne - 2);
  mangec = 1 + rand() % (colone - 2);

  if (piece[mangel][mangec] == 0) {
    piece[mangel][mangec] = -1;
  } else {
    mange();
  }
}

void game() {
  for (i = 0; i < ligne; i++) {
    for (j = 0; j < colone; j++) {
      if (i == 0 && j == 0) printf("\t \t \t %c", 201);
      else if (i == 0 && j == colone - 1) printf("%c", 187);
      else if (i == ligne - 1 && j == 0) printf("\t \t \t %c", 200);
      else if (i == ligne - 1 && j == colone - 1) printf("%c", 188);
      else if (i == 0 || i == ligne - 1) printf("%c", 205);
      else if (j == 0) printf("\t \t \t %c", 186);
      else if (j == colone - 1) printf("%c", 186);
      else {
        if (piece[i][j] == 0) {
        	printf(" ");
		}
        else if (piece[i][j] >= 1 && piece[i][j] != head){
        	printf("%c", 176);
		}
        else if (piece[i][j] == head){
        	printf("%c", 178);
		}
        else if (piece[i][j] == -1) {
        	printf("%c", 184);
		}
      }
    }
    printf("\n");
  }
}

void controle() {
  if (kbhit()) {
    nDir = getch();
    if (nDir == 0)
      nDir = getch();
  }
  if ((nDir == KEY_UP && nDir2 != KEY_DOWN) || (nDir == KEY_DOWN && nDir2 != KEY_UP) || (nDir == KEY_RIGHT && nDir2 != KEY_LEFT) || (nDir == KEY_LEFT && nDir2 != KEY_RIGHT)) {
    nDir2 = nDir;
  }
  if (st == 1) {
    nDir2 = KEY_UP;
    st = 0;
  }
  switch (nDir2) {
  case KEY_UP: {
    head++;
    snakel--;
    if (piece[snakel][snakec] != 0 && snakel != mangel) {
      move = 7;
    }
    piece[snakel][snakec] = head;
    break;
  }
  case KEY_DOWN: {
    head++;
    snakel++;
    if (piece[snakel][snakec] != 0 && snakel != mangel) {
      move = 7;
    }
    piece[snakel][snakec] = head;
    break;
  }
  case KEY_RIGHT: {
    head++;
    snakec++;
    if (piece[snakel][snakec] != 0 && snakec != mangec) {
      move = 7;
    }
    piece[snakel][snakec] = head;
    break;
  }
  case KEY_LEFT: {
    head++;
    snakec--;
    if (piece[snakel][snakec] != 0 && snakec != mangec) {
      move = 7;
    }
    piece[snakel][snakec] = head;
    break;
  }
	default:;
  }

  for (i = 0; i < ligne; i++) {
    for (j = 0; j < colone; j++) {
      if ((piece[i][j] == Tail)) {
        piece[i][j] = 0;
      }
    }
  }
  Tail++;

  if (snakel <= 0 || snakel >= ligne || snakec <= 0 || snakec >= colone) {
    sleep(1);
    move = 7;
    system("cls");
  }

  if (snakel == mangel && snakec == mangec) {
    player.score += 10;
    Tail -= 1;
    mange();
  }
}

void ResetScreenPosition() {
  HANDLE hOut;
  COORD Position;
  hOut = GetStdHandle(STD_OUTPUT_HANDLE);
  Position.X = 0;
  Position.Y = 0;
  SetConsoleCursorPosition(hOut, Position);
}

/////// fonction ////////

int longueurChaine(const char * chaine) {
  int nombreDeCaracteres = 0;
  char caractereActuel = 0;

  do {
    caractereActuel = chaine[nombreDeCaracteres];
    nombreDeCaracteres++;
  }
  while (caractereActuel != '\0');

  nombreDeCaracteres--;

  return nombreDeCaracteres;
}

void Users();
void back();

void Users() {
  c = d = 0;
  f = fopen("users.txt", "r");
  if (f == NULL) {
    move = 10;
  } else {
    fseek(f, 0, SEEK_END);
    pos_max = ftell(f);
    printf("\n \n \n");
    printf("\t\t\t\t\t    Username : ");
    scanf("%s", player.user);
    int longueur = longueurChaine(player.user);
    if (longueur != 4) {
      system("cls");
      Users();
    }
    for (pos = 0; pos < pos_max; pos += 5) {
      rewind(f);
      fseek(f, pos, SEEK_CUR);
      fscanf(f, "%s", lire);
      cmp_user = strcmp(lire, player.user);
      if (cmp_user == 0) {
        c = 1;
        d = 0;
        break;
      } else {
        d = 1;
      }
    }
    fclose(f);
  }
}
void back() {
  printf("\n \n \t\t\t\t Do you want continue == 1 or back == 0");
  printf("\n\n\t\t\t\t\t\t     ");
  bc = getch();
  if (bc == '1') {
    system("cls");
    Users();
  } else if (bc == '0') {
    move = 0;
  }
  while (bc != '1' && bc != '0') {
    system("cls");
    back();
  }
}
/////// graphics ////////

void intro() {
  system("cls");
  printf("\n \t \t       ------------------------------------------------");
  printf("\n \t \t       |                   WELCOME                    |");
  printf("\n \t \t       |                     TO                       |");
  printf("\n \t \t       |                 SNAKE GAME                   |");
  printf("\n \t \t       |                                              |");
  printf("\n \t \t       |               NEW GAME    == 1               |");
  printf("\n \t \t       |               CONTINUE    == 2               |");
  printf("\n \t \t       |               CONTROLE    == 3               |");
  printf("\n \t \t       |               CHECK       == 4               |");
  printf("\n \t \t       |               RANKING     == 5               |");
  printf("\n \t \t       |                                              |");
  printf("\n \t \t       |                QUIT      == 9                |");
  printf("\n \t \t       ------------------------------------------------");
  if (kbhit()) {
    press = getch();
  }
  switch (press) {
  case 49:
    move = 1;
    break;
  case 50:
    move = 2;
    break;
  case 51:
    move = 3;
    break;
  case 52: {
    system("cls");
    move = 44;
    break;
  }
  case 53: {
    system("cls");
    move = 88;
    break;
  }
  case 57:
    move = 9;
    break;
  default:;
  }
  press = 100;
}

void NEWGAME() {
  system("cls");
  com = 1;
  com1 = 1;
  printf("\n \t \t       *******************************************************");
  printf("\n \t \t       *                                                     *");
  printf("\n \t \t       *          username must contain four lettres         *");
  printf("\n \t \t       *                                                     *");
  printf("\n \t \t       *                        example                      *");
  printf("\n \t \t       *                                                     *");
  printf("\n \t \t       *                AdminUsername : maro                 *");
  printf("\n \t \t       *                                                     *");
  printf("\n \t \t       *******************************************************");
  Users();
  if (c == 1) {
    printf("\n\t\t\t\t        Username already exists");
    back();
    c = 0;
  }
  if (d == 1) {
    f = fopen("users.txt", "a");
    if (f == NULL) {
      move = 10;
    } else {
      fprintf(f, "%s ", player.user);
      fclose(f);
    }

    nbPlayers();
    move = 22;

    d = 0;
  }
}

void CONTINUE() {
  system("cls");
  com = 2;
  com1 = 2;
  Users();
  if (c == 1) {
    move = 22;
    c = 0;
  }
  if (d == 1) {
    printf("\n\t\t\t\t\t Username does not exist ");
    back();
    d = 0;
  }

}

void niveau (){
		system("cls");
		printf("\n \t \t       -------------------------------------------------");
	    printf("\n \t \t       |                                               |");
		printf("\n \t \t       |                                               |");
		printf("\n \t \t       |                                               |");
		printf("\n \t \t       |                  easy   == 0                  |");
		printf("\n \t \t       |                  medium == 1                  |");
		printf("\n \t \t       |                  hard   == 2                  |");
		printf("\n \t \t       |                                               |");
		printf("\n \t \t       |                                               |");
		printf("\n \t \t       |                                               |");
		printf("\n \t \t       -------------------------------------------------");
		
		if (kbhit()){
			press = getch();
		}
		switch(press){
			case 48: 
				speed = 99;
				move = 5;
				break;
			case 49: 
				speed = 50;
				move = 5;
				break;	
            case 50: 
				speed = 20;
				move = 5;
				break;
			default:;		
		}
	}

void lire_fichier();

void CHECK() {
  system("cls");
  Users();
  if (c == 1) {
    lire_fichier();
    back();
    c = 0;
  }
  if (d == 1) {
    printf("\n\t\t\t\t\t Username does not exist ");
    back();
    d = 0;
  }
}

void lire_fichier() {
  system("cls");
  char ro;
  f = fopen(("%s", player.user), "r");
  if (f == NULL) {
    move = 10;
  } {
    rewind(f);
    do {
      ro = fgetc(f);
      printf("%c", ro);
      if (ro == '\n') {
        printf("\t \t \t \t \t \t");
      }
    } while (ro != EOF);
    fclose(f);
  }
}

void CONTROLE() {
    system("cls");
	printf("\n \t \t       ------------------------------------------------");
    printf("\n \t \t       |                                              |");
	printf("\n \t \t       |                                              |");
	printf("\n \t \t       |                                              |");
	printf("\n \t \t       |                  ARROW KEYS                  |");
	printf("\n \t \t       |                  QUIT  == 9                  |"); 
	printf("\n \t \t       |                                              |");
	printf("\n \t \t       |                                              |");
	printf("\n \t \t       |                                              |");
	printf("\n \t \t       |                                   BACK == 0  |");
	printf("\n \t \t       ------------------------------------------------");
	if (kbhit()){
		press = getch();
	}
	if (press == 48 ){
		move = 0;
	}
  if (kbhit()) {
    press = getch();
  }
  if (press == 48) {
    move = 0;
  }
}

void QUIT() {
  system("cls");
  printf("\n \t \t       ------------------------------------------------");
  printf("\n \t \t       |                                              |");
  printf("\n \t \t       |                                              |");
  printf("\n \t \t       |                                              |");
  printf("\n \t \t       |                    SEE YOU                   |");
  printf("\n \t \t       |                     LATER                    |");
  printf("\n \t \t       |                    SNAKIES                   |");
  printf("\n \t \t       |                                              |");
  printf("\n \t \t       |                                              |");
  printf("\n \t \t       |                                              |");
  printf("\n \t \t       ------------------------------------------------");
}

void START() {
  system("cls");
  printf("\n \t \t       -------------------------------------------------");
  printf("\n \t \t       |                                               |");
  printf("\n \t \t       |                                               |");
  printf("\n \t \t       |                                               |");
  printf("\n \t \t       |                                               |");
  printf("\n \t \t       |                  PRESS ESPACE                 |");
  printf("\n \t \t       |                    TO PLAY                    |");
  printf("\n \t \t       |                                               |");
  printf("\n \t \t       |                                               |");
  printf("\n \t \t       |                                               |");
  printf("\n \t \t       -------------------------------------------------");

  if (kbhit()) {
    press = getch();
  }
  if (press == 32) {
    system("cls");
    move = 6;
  }
}

void hgscore(){
  f=fopen("score.txt","a+");
  FILE* f1;
  char c;
  pos = 0;
  if(f==NULL) move = 10;
  else{
	if(com1==1 ){fprintf(f,"%s %d %d \n",player.user,player.score,player.nb_player); }
	else if(com1==2) {
			fseek(f, 0, SEEK_END);
			pos_max=ftell(f);
			f1=fopen("score_new.txt","w");
			for(pos=0;pos<(pos_max);pos+=5){ 
			pos-=5;
			rewind(f);
			fseek(f,pos,SEEK_CUR);
			fscanf(f,"%s",&lire);
			fprintf(f1,"%s ",lire);
			if(strcmp(lire,player.user)==0){  fscanf(f,"%d",&get_int); fprintf(f1,"%d ",max(get_int,player.score));
											  fscanf(f,"%d",&get_int); fprintf(f1,"%d \n ",get_int);
										}
			else{ fscanf(f,"%d",&get_int); fprintf(f1,"%d ",get_int); fscanf(f,"%d",&get_int); fprintf(f1,"%d \n",get_int);}
			pos=ftell(f); 		
			};
			fclose(f1); fclose(f);
			f=fopen("score.txt","w"); 
			f1=fopen("score_new.txt","r");		
			rewind(f); rewind(f1);
			fseek(f1,0,SEEK_END);
			pos_max=ftell(f1);
			rewind(f1);
		
		     	for(pos=0;pos<pos_max;pos++){
		     		c=fgetc(f1);
		     		fputc(c,f);
					 pos=ftell(f1);	
				 }
			fclose(f1);
			} 
		com1=0;
	}
	fclose(f);
}

void GAMEOVER() {
  system("cls");
  printf("\n \t \t       ---------------------------------------------------");
  printf("\n \t \t       |                                                 |");
  printf("\n \t \t       |                HighScore : %d                   |", HS);
  printf("\n \t \t       |                                                 |");
  printf("\n \t \t       |                  SCORE : %d                     |", player.score);
  printf("\n \t \t       |                                                 |");
  printf("\n \t \t       |                     GAME                        |");
  printf("\n \t \t       |                     OVER                        |");
  printf("\n \t \t       |                                                 |");
  printf("\n \t \t       |                  Back   == 0                    |");
  printf("\n \t \t       |                  REPLAY == 1                    |");
  printf("\n \t \t       |                  QUIT   == 9                    |");
  printf("\n \t \t       |                                                 |");
  printf("\n \t \t       ---------------------------------------------------");

  Highscore();
  hgscore();

  if (kbhit()) {
    press = getch();
  }
  switch (press) {
  case 57:
    move = 9;
    break;
  case 48:
  	initialisation();
    move = 0;
    break;
  case 49: {
    system("cls");
    initialisation();
    press = 100;
    move = 22;
    break;
  }
  default:
    ;
  }
}

void Error() {
  system("cls");
  printf("\n \t \t       ------------------------------------------------");
  printf("\n \t \t       |                                              |");
  printf("\n \t \t       |                                              |");
  printf("\n \t \t       |                                              |");
  printf("\n \t \t       |                    INTERNAL                  |");
  printf("\n \t \t       |                                              |");
  printf("\n \t \t       |                  SERVER ERROR                |");
  printf("\n \t \t       |                                              |");
  printf("\n \t \t       |                                              |");
  printf("\n \t \t       |                                              |");
  printf("\n \t \t       ------------------------------------------------");
}

void classement(){
	f = fopen("nb_players.txt", "r");
    if (f == NULL) {move = 10;}
	else {
    fscanf(f, "%d", & nb_total);
    fclose(f);
	}
	
	struct players hg_score[nb_total];
	f=fopen("score.txt","r");
	if (f==NULL) move=10;
	else{
	fseek(f,0,SEEK_END);
	pos_max=ftell(f);
	i=0;
		for(pos=0;pos<pos_max;pos+=2){
			pos-=2;
			rewind(f);
			fseek(f,pos,SEEK_CUR);
			fscanf(f,"%s",&(hg_score[i].user));
			fscanf(f,"%d",&(hg_score[i].score));
			fscanf(f,"%d",&(hg_score[i].nb_player));
			pos=ftell(f);
			i++;
		}  // On stocke les infos 
	} 
	fclose(f);
	struct players temporaire[nb_total];
	// mettre les scores en ordre d�croissant 
	i=0; j=0; k=0;
	for(i=0;i<nb_total;i++){
		temporaire[i].score=hg_score[i].score;
		for(j=i;j<nb_total;j++){
			if((temporaire[i].score)<(hg_score[j].score)){
				(temporaire[i].score)=(hg_score[j].score);
				k=j;
			}
			
		}
		if(temporaire[i].score!=hg_score[i].score){
		strcpy( temporaire[i].user , hg_score[k].user );
		(temporaire[i].nb_player) = (hg_score[k].nb_player);
		
		strcpy( hg_score[k].user, hg_score[i].user );
		(hg_score[k].score) = (hg_score[i].score);
		(hg_score[k].nb_player) = (hg_score[i].nb_player);
		
		strcpy(hg_score[i].user , temporaire[i].user);
		hg_score[i].nb_player = temporaire[i].nb_player;
		hg_score[i].score = temporaire[i].score;
		
		}
	}
		// On affiche le classement
		printf(" \n\tClassement: \n");
		printf("\t\t\t classement \t\t username \t\t high score \t\t ID \n");
		for(i=0;i<nb_total;i++){
			printf("\t\t\t  %d \t\t\t %s \t\t\t %d \t\t\t %d \n",i+1,hg_score[i].user,hg_score[i].score,hg_score[i].nb_player);
		}	
		
	printf("\n\n\n \t\t\t\t\t\t\t\t\t\t\t\t back == 0");
	if (kbhit()){
		press = getch();
	}
	if (press == 48 ){
		move = 0;
	}
	
}


void main() {
  initialisation();
  while (gameover == 0) {
    if (move == 0) {
      sleep(1);
      ResetScreenPosition();
      intro();
    }
    else if (move == 1) {
      sleep(1);
      ResetScreenPosition();
      NEWGAME();
    }
    else if (move == 2) {
      sleep(1);
      CONTINUE();
      ResetScreenPosition();
    }
    else if (move == 3) {
      sleep(1);
      ResetScreenPosition();
      CONTROLE();
    }
    else if (move == 44) {
      sleep(1);
      ResetScreenPosition();
      CHECK();
    }
    else if (move == 88) {
      sleep(1);
      ResetScreenPosition();
      classement();
	}
    else if (move == 7) {
        sleep(1);
      while (st == 0) {
        data();
        st = 1;
      }
      ResetScreenPosition();
      GAMEOVER();
    }
    else if (move == 22){
        sleep(1);
        ResetScreenPosition();		
    	niveau();
    }
    else if (move == 5) {
      sleep(1);
      ResetScreenPosition();
      START();
    }
    else if (move == 6) {
      Sleep(speed);
      controle();
      ResetScreenPosition();
      game();
    }
    else if (move == 9) {
      QUIT();
      gameover = 1;
    }
    else if (move == 10) {
      Error();
      gameover = 1;
    }
  }
}
